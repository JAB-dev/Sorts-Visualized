staticSort is able to operate in-place if the maximum number of the input array is less than the size of it
